function displayUserInput(elem) {
  var elem = document.getElemenyById("userInput");
  alert(elem);
}

